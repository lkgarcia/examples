/* This is the intra-libnetpbm interface header file for libpbm*.c
*/

#ifndef LIBPBM_H_INCLUDED
#define LIBPBM_H_INCLUDED

void
pbm_readpbminitrest(FILE * file,
                    int  * colsP,
                    int *  rowsP);

#endif
