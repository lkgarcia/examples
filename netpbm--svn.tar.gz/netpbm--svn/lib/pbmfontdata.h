extern struct font pbm_defaultFixedfont;
extern struct font pbm_defaultBdffont;

extern struct font2 const pbm_defaultFixedfont2;
extern struct font2 const pbm_defaultBdffont2;

extern struct font2 const * pbm_builtinFonts[];
