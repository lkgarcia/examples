int
vax_gshort(char *msgp);

char *
vax_pshort(char *msgp, unsigned short s);
