#ifndef FILENAME_H_INCLUDED
#define FILENAME_H_INCLUDED

const char *
pm_basename(const char * const fileName);

#endif
