#ifndef NSLEEP_H_INCLUDED
#define NSLEEP_H_INCLUDED

void
pm_sleep(unsigned int const milliseconds);

#endif
